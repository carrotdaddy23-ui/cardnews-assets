# 부록 파일 묶음: 설치·사용법

전자책 구매자용 파일입니다. 8장에서 설명한 "AI 직원 지시서" 스킬 3개와 원가계산기 엑셀이 들어 있습니다.

원가계산기.xlsx 는 노란 칸만 채우면 됩니다. 칸 이름은 책 부록 C와 같습니다.

| 스킬 | 하는 일 | 호출 예 |
|---|---|---|
| sourcing-review | 키워드 확장 → 원가계산 → GO/NO 판정 리포트 | "/sourcing-review 캠핑 랜턴" |
| cost-check | 원가·마진만 빠르게 계산 (부록 C 로직) | "/cost-check 단가 12위안 100개…" |
| product-page | 상품명 후보 + 상세페이지 초안 생성 | "/product-page 사양 붙여넣기" |

## 설치 (Claude Code 사용자)

1. 내 작업 폴더(예: `C:\셀러사무실`) 아래에 `.claude\skills\` 폴더를 만듭니다.
2. 이 팩의 폴더 3개(sourcing-review, cost-check, product-page)를 통째로 복사해 넣습니다.
   - 최종 구조: `C:\셀러사무실\.claude\skills\sourcing-review\SKILL.md` (나머지도 동일)
3. Claude Code를 그 폴더에서 실행하고 `/sourcing-review 아이템명` 처럼 부르면 끝.

## 설치 없이 쓰는 법 (Claude 앱·웹 사용자)

각 폴더의 SKILL.md 내용을 통째로 복사해서 채팅창에 붙여넣고, 맨 아래에 내 아이템 정보를 적으면 동일하게 작동합니다.

## 커스터마이징

- 각 SKILL.md 안의 [기본값] 표시 수치(수수료율, 광고비율, 마진 기준)는 내 채널에 맞게 수정해서 쓰세요.
- 결과물이 마음에 들면 그 결과를 낳은 조건을 SKILL.md에 추가하세요. 스킬은 쓸수록 나만의 매뉴얼이 됩니다.
